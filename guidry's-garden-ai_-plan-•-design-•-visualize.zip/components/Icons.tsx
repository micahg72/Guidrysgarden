
import React from 'react';

export const MicIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
    <path d="M12 2a3 3 0 0 0-3 3v6a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Zm0 12a5 5 0 0 1-5-5V5a5 5 0 0 1 10 0v6a5 5 0 0 1-5 5Z" />
    <path d="M19 11a1 1 0 0 1 1 1v.5a8 8 0 0 1-16 0V12a1 1 0 0 1 2 0v.5a6 6 0 0 0 12 0V12a1 1 0 0 1 1-1Z" />
  </svg>
);

export const StopIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 2c5.523 0 10 4.477 10 10s-4.477 10-10 10S2 17.523 2 12 6.477 2 12 2Zm0 2a8 8 0 1 0 0 16 8 8 0 0 0 0-16Zm-2 4v8h8v-8H8Z"/>
    </svg>
);


export const SendIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
    <path d="M3.478 2.405a.75.75 0 00-.926.94l2.432 7.905H13.5a.75.75 0 010 1.5H4.984l-2.432 7.905a.75.75 0 00.926.94 60.519 60.519 0 0018.445-8.986.75.75 0 000-1.218A60.517 60.517 0 003.478 2.405z" />
  </svg>
);

export const HeartIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
    <path d="M11.645 20.91l-.007-.003-.022-.012a15.247 15.247 0 01-1.344-.688 15.182 15.182 0 01-1.06-1.012c-.31-.433-.6-1.015-.8-1.766-1.8-7.222 5.068-11.54 9.39-7.221a.75.75 0 01-1.06 1.062 10.536 10.536 0 00-6.736-2.94c-4.482 0-8.08 3.582-8.08 8.082 0 1.228.32 2.404.9 3.492l.02.032.02.031.025.035c.18.24.39.47.62.693a13.785 13.785 0 001.319 1.118l.002.001.002.001.002.001a.75.75 0 01-1.06 1.062zM20.57 4.43a.75.75 0 011.06 1.06l-6.97 6.97a.75.75 0 01-1.06 0l-3.47-3.47a.75.75 0 011.06-1.06l2.94 2.94 6.44-6.44z" />
  </svg>
);

export const DownloadIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
    <path d="M12 2c-5.523 0-10 4.477-10 10s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2ZM12 14.25a.75.75 0 0 1-.75-.75V8.56l-1.628 1.628a.75.75 0 0 1-1.06-1.06l3-3a.75.75 0 0 1 1.06 0l3 3a.75.75 0 0 1-1.06 1.06L12.75 8.56v4.94c0 .414-.336.75-.75.75Zm-5.25 3a.75.75 0 0 0 0 1.5h10.5a.75.75 0 0 0 0-1.5H6.75Z" />
  </svg>
);

export const UploadIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
    <path fillRule="evenodd" d="M10.5 3.75a2.25 2.25 0 00-2.25 2.25v10.19l-1.72-1.72a.75.75 0 00-1.06 1.06l3 3a.75.75 0 001.06 0l3-3a.75.75 0 10-1.06-1.06l-1.72 1.72V6a2.25 2.25 0 00-2.25-2.25z" clipRule="evenodd" />
    <path d="M6.75 12a.75.75 0 000 1.5h10.5a.75.75 0 000-1.5H6.75z" />
  </svg>
);

export const SparklesIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
    <path fillRule="evenodd" d="M9.315 7.584C12.195 3.883 16.695 1.5 21.75 1.5a.75.75 0 01.75.75c0 5.056-2.383 9.555-6.084 12.436A6.75 6.75 0 019.75 22.5a.75.75 0 01-.75-.75v-7.19c0-1.76 1.44-3.2 3.2-3.2s3.2 1.44 3.2 3.2v2.268c.262-.102.53-.192.802-.286V15c0-2.652-2.148-4.8-4.8-4.8s-4.8 2.148-4.8 4.8v.006c-.346.03-.69.066-1.034.102V15c0-4.142 3.358-7.5 7.5-7.5 1.135 0 2.212.253 3.185.717a.75.75 0 01-1.04 1.086A5.98 5.98 0 0017.25 9c-3.313 0-6 2.687-6 6v.089c-.563.083-1.112.19-1.65.317V15a6.75 6.75 0 01-6.75-6.75.75.75 0 01.75-.75c2.69 0 5.151 1.04 7.014 2.754a.75.75 0 01-1.056 1.056z" clipRule="evenodd" />
  </svg>
);

export const GoogleDriveIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
    <path d="M6.22 3.125L3 8.375l8.938 12.5h5.812L8.812 3.125H6.22zM8.406 4.375l8.344 14.375L21 11.25l-4.5-7.813-8.094.938zM5.53 9.375l-1.5 2.625 7.938 5.469 1.5-2.625-7.938-5.469z"/>
  </svg>
);

export const DeployIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
        <path fillRule="evenodd" d="M9.401 3.949c.426-.233.955-.233 1.381 0l8.25 4.5a.75.75 0 010 1.302l-8.25 4.5a.75.75 0 01-1.38-.651V8.651L3.901 12l5.5 3.001v3.698a.75.75 0 01-1.38.651l-8.25-4.5a.75.75 0 010-1.302l8.25-4.5zM8.25 7.933 5.401 9.5 8.25 11.067V7.933zm1.5 1.134v6.866L15.601 12 9.75 9.067z" clipRule="evenodd" />
    </svg>
);

export const CloseIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
      <path fillRule="evenodd" d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25zm-1.72 6.97a.75.75 0 00-1.06 1.06L10.94 12l-1.72 1.72a.75.75 0 101.06 1.06L12 13.06l1.72 1.72a.75.75 0 101.06-1.06L13.06 12l1.72-1.72a.75.75 0 10-1.06-1.06L12 10.94l-1.72-1.72z" clipRule="evenodd" />
    </svg>
);
