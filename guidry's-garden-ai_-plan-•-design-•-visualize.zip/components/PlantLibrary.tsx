
import React, { useState } from 'react';
import { Plant } from '../types';
import PlantCard from './PlantCard';
import { SparklesIcon } from './Icons';

interface PlantLibraryProps {
  plants: Plant[];
  favorites: string[];
  onToggleFavorite: (plantId: string) => void;
  onSearch: (query: string) => void;
  isLoading: boolean;
}

const PlantLibrary: React.FC<PlantLibraryProps> = ({ plants, favorites, onToggleFavorite, onSearch, isLoading }) => {
  const [query, setQuery] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      onSearch(query);
    }
  };

  return (
    <div className="bg-white/80 backdrop-blur-sm border border-green-200/50 rounded-2xl shadow-lg flex flex-col h-full">
      <div className="p-4 border-b border-green-200/50">
        <h2 className="text-2xl font-bold text-green-900">Plant Library</h2>
        <p className="text-sm text-gray-600">Discover plants for your garden.</p>
      </div>
      <form onSubmit={handleSearch} className="p-4 border-b border-green-200/50">
        <div className="relative">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="e.g., 'low-maintenance flowers for shade'"
            className="w-full pl-4 pr-10 py-2 border border-gray-300 rounded-full focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors"
          />
          <button
            type="submit"
            className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-green-600 text-white rounded-full hover:bg-green-700 transition-colors disabled:bg-gray-400"
            disabled={isLoading || !query.trim()}
          >
            <SparklesIcon className="w-5 h-5" />
          </button>
        </div>
      </form>
      <div className="flex-grow p-4 overflow-y-auto">
        {isLoading ? (
          <div className="flex justify-center items-center h-full">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-700"></div>
          </div>
        ) : plants.length > 0 ? (
          <div className="grid grid-cols-1 gap-4">
            {plants.map((plant) => (
              <PlantCard
                key={plant.id}
                plant={plant}
                isFavorite={favorites.includes(plant.id)}
                onToggleFavorite={onToggleFavorite}
              />
            ))}
          </div>
        ) : (
          <div className="text-center text-gray-500 mt-8">
            <p>No plants found.</p>
            <p className="text-sm">Try searching for something!</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default PlantLibrary;
