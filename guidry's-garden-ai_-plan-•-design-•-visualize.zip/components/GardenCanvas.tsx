
import React, { useRef, useState, useImperativeHandle, forwardRef } from 'react';
import { DownloadIcon, UploadIcon, SparklesIcon, GoogleDriveIcon, CloseIcon } from './Icons';
import { Plant, PlacedPlant } from '../types';

interface GardenCanvasProps {
  image: string | null;
  isLoading: boolean;
  onImageUpload: (file: File) => void;
  isSignedIn: boolean;
  onSaveToDrive: () => void;
  onSignIn: () => void;
  isSavingToDrive: boolean;
  isAuthReady: boolean;
}

export interface GardenCanvasRef {
  generateLayoutImage: () => Promise<string | null>;
}

const GardenCanvas = forwardRef<GardenCanvasRef, GardenCanvasProps>(({ image, isLoading, onImageUpload, isSignedIn, onSaveToDrive, onSignIn, isSavingToDrive, isAuthReady }, ref) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasContainerRef = useRef<HTMLDivElement>(null);
  const [placedPlants, setPlacedPlants] = useState<PlacedPlant[]>([]);
  const [isDraggingOver, setIsDraggingOver] = useState(false);

  useImperativeHandle(ref, () => ({
    generateLayoutImage: async () => {
      if (!image) return null;
      
      return new Promise((resolve) => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        if (!ctx) return resolve(null);

        const bgImage = new Image();
        bgImage.src = `data:image/jpeg;base64,${image}`;
        bgImage.onload = () => {
          canvas.width = bgImage.naturalWidth;
          canvas.height = bgImage.naturalHeight;
          
          ctx.drawImage(bgImage, 0, 0);

          // Render plants on the canvas
          placedPlants.forEach(({ plant, position }) => {
            const containerRect = canvasContainerRef.current?.getBoundingClientRect();
            if(!containerRect) return;

            // Scale position from container dimensions to canvas dimensions
            const x = (position.x / containerRect.width) * canvas.width;
            const y = (position.y / containerRect.height) * canvas.height;
            
            ctx.beginPath();
            ctx.arc(x, y, 20, 0, 2 * Math.PI, false);
            ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
            ctx.fill();
            ctx.lineWidth = 2;
            ctx.strokeStyle = '#15803d'; // green-700
            ctx.stroke();

            ctx.fillStyle = '#14532d'; // green-900
            ctx.font = 'bold 20px sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(plant.name.charAt(0).toUpperCase(), x, y);
          });

          resolve(canvas.toDataURL('image/jpeg').split(',')[1]);
        };
        bgImage.onerror = () => resolve(null);
      });
    },
  }));
  
  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setPlacedPlants([]); // Clear plants when new image is uploaded
      onImageUpload(file);
    }
  };

  const handleDownload = async () => {
    const finalImage = await (ref as React.RefObject<GardenCanvasRef>)?.current?.generateLayoutImage();
    if (finalImage) {
      const link = document.createElement('a');
      link.href = `data:image/jpeg;base64,${finalImage}`;
      link.download = 'guidrys-garden-layout.jpeg';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    setIsDraggingOver(true);
  };
  
  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDraggingOver(false);
    const containerRect = canvasContainerRef.current?.getBoundingClientRect();
    if (!containerRect) return;

    // Calculate drop position relative to the container
    const x = e.clientX - containerRect.left;
    const y = e.clientY - containerRect.top;

    // Check if we are moving an existing plant
    const movedPlantData = e.dataTransfer.getData('text/plain');
    if (movedPlantData) {
        const {instanceId, offsetX, offsetY} = JSON.parse(movedPlantData);
        setPlacedPlants(prev => prev.map(p => p.instanceId === instanceId ? {...p, position: {x: x - offsetX, y: y- offsetY}} : p));
        return;
    }

    // Check if we are adding a new plant
    const plantData = e.dataTransfer.getData('application/json');
    if (plantData) {
        const plant: Plant = JSON.parse(plantData);
        const newPlacedPlant: PlacedPlant = {
            instanceId: `${plant.id}-${Date.now()}`,
            plant,
            position: { x, y: y },
        };
        setPlacedPlants(prev => [...prev, newPlacedPlant]);
    }
  };

  const handlePlantDragStart = (e: React.DragEvent<HTMLDivElement>, plant: PlacedPlant) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const offsetX = e.clientX - rect.left;
    const offsetY = e.clientY - rect.top;
    e.dataTransfer.setData('text/plain', JSON.stringify({instanceId: plant.instanceId, offsetX, offsetY}));
    e.dataTransfer.effectAllowed = 'move';
  };

  const removePlant = (instanceId: string) => {
    setPlacedPlants(prev => prev.filter(p => p.instanceId !== instanceId));
  };


  return (
    <div 
        ref={canvasContainerRef}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
        onDragLeave={() => setIsDraggingOver(false)}
        className={`relative w-full h-full bg-green-100/50 rounded-2xl shadow-inner overflow-hidden flex items-center justify-center transition-all duration-300 ${isDraggingOver ? 'ring-4 ring-green-500 ring-offset-2' : ''}`}
    >
      {isLoading && (
        <div className="absolute inset-0 bg-black/50 flex flex-col items-center justify-center z-20">
          <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-white"></div>
          <p className="text-white text-lg mt-4">AI is creating your garden...</p>
        </div>
      )}
      {image ? (
        <img src={`data:image/jpeg;base64,${image}`} alt="Generated Garden" className="w-full h-full object-contain pointer-events-none" />
      ) : (
        <div className="text-center text-green-800 p-8">
          <SparklesIcon className="w-24 h-24 mx-auto text-green-300" />
          <h2 className="mt-4 text-3xl font-bold">Design Your Dream Garden</h2>
          <p className="mt-2 text-lg">Use the chat to describe your perfect garden, or upload a photo of your space to get started! You can then drag plants from the library onto your design.</p>
        </div>
      )}

      {/* Render Placed Plants */}
      {placedPlants.map((p) => (
        <div
            key={p.instanceId}
            draggable
            onDragStart={(e) => handlePlantDragStart(e, p)}
            style={{ 
                position: 'absolute', 
                left: `${p.position.x}px`, 
                top: `${p.position.y}px`,
                transform: 'translate(-50%, -50%)',
            }}
            className="group w-10 h-10 rounded-full bg-white/80 backdrop-blur-sm shadow-lg flex items-center justify-center cursor-grab ring-2 ring-green-700 hover:ring-4 transition-all"
            title={p.plant.name}
        >
            <span className="text-lg font-bold text-green-900 select-none">{p.plant.name.charAt(0).toUpperCase()}</span>
            <button 
                onClick={() => removePlant(p.instanceId)}
                className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                aria-label={`Remove ${p.plant.name}`}
            >
                <CloseIcon className="w-5 h-5"/>
            </button>
        </div>
      ))}


      <div className="absolute top-4 right-4 flex gap-3">
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          className="hidden"
          accept="image/*"
        />
        <button
          onClick={handleUploadClick}
          className="bg-white/80 backdrop-blur-sm text-green-800 font-semibold py-2 px-4 rounded-full shadow-md hover:bg-white transition-all duration-300 flex items-center gap-2"
        >
          <UploadIcon className="w-5 h-5" />
          Upload Space
        </button>
        <button
          onClick={handleDownload}
          disabled={!image}
          className="bg-white/80 backdrop-blur-sm text-green-800 font-semibold py-2 px-4 rounded-full shadow-md hover:bg-white transition-all duration-300 flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <DownloadIcon className="w-5 h-5" />
          Download
        </button>
        {isAuthReady && (
          isSignedIn ? (
            <button
              onClick={onSaveToDrive}
              disabled={!image || isSavingToDrive}
              className="bg-white/80 backdrop-blur-sm text-green-800 font-semibold py-2 px-4 rounded-full shadow-md hover:bg-white transition-all duration-300 flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <GoogleDriveIcon className="w-5 h-5" />
              {isSavingToDrive ? 'Saving...' : 'Save to Drive'}
            </button>
          ) : (
            <button
              onClick={onSignIn}
              className="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded-full shadow-md transition-all duration-300 flex items-center gap-2"
            >
              <GoogleDriveIcon className="w-5 h-5" />
              Sign in to Save
            </button>
          )
        )}
      </div>
    </div>
  );
});

export default GardenCanvas;
