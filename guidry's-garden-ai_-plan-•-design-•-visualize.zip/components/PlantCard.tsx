
import React from 'react';
import { Plant } from '../types';
import { HeartIcon } from './Icons';

interface PlantCardProps {
  plant: Plant;
  isFavorite: boolean;
  onToggleFavorite: (plantId: string) => void;
}

const PlantCard: React.FC<PlantCardProps> = ({ plant, isFavorite, onToggleFavorite }) => {
  const handleDragStart = (e: React.DragEvent<HTMLDivElement>) => {
    e.dataTransfer.setData('application/json', JSON.stringify(plant));
    e.dataTransfer.effectAllowed = 'move';
  };

  return (
    <div
      draggable
      onDragStart={handleDragStart}
      className="bg-white rounded-lg shadow-md p-4 flex flex-col justify-between transition-all duration-300 hover:shadow-xl hover:scale-105 cursor-grab"
    >
      <div>
        <div className="flex justify-between items-start">
          <h3 className="text-lg font-bold text-green-800">{plant.name}</h3>
          <button
            onClick={() => onToggleFavorite(plant.id)}
            className={`p-1 rounded-full transition-colors ${isFavorite ? 'text-red-500 bg-red-100' : 'text-gray-400 hover:bg-gray-100'}`}
            aria-label={isFavorite ? 'Remove from favorites' : 'Add to favorites'}
          >
            <HeartIcon className="w-6 h-6" />
          </button>
        </div>
        <p className="text-sm text-gray-600 mt-2">{plant.description}</p>
      </div>
      <div className="mt-4 flex flex-wrap gap-2 text-xs">
        <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full">{plant.type}</span>
        <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full">{plant.season}</span>
        <span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full">Care: {plant.careLevel}</span>
      </div>
    </div>
  );
};

export default PlantCard;
