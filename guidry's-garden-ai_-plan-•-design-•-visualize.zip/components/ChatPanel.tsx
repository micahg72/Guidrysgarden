
import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage } from '../types';
import { SendIcon, MicIcon, StopIcon, SparklesIcon, DeployIcon } from './Icons';

interface ChatPanelProps {
  messages: ChatMessage[];
  onSendMessage: (text: string) => void;
  isRecording: boolean;
  onToggleRecording: () => void;
  currentTranscription: string;
  isLoading: boolean;
  onUploadApp: () => void;
  isUploadingApp: boolean;
  isSignedIn: boolean;
  isAuthReady: boolean;
}

const ChatPanel: React.FC<ChatPanelProps> = ({ messages, onSendMessage, isRecording, onToggleRecording, currentTranscription, isLoading, onUploadApp, isUploadingApp, isSignedIn, isAuthReady }) => {
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [messages, currentTranscription]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputText.trim()) {
      onSendMessage(inputText);
      setInputText('');
    }
  };

  return (
    <div className="bg-white/80 backdrop-blur-sm border border-green-200/50 rounded-2xl shadow-lg flex flex-col h-full">
      <div className="p-4 border-b border-green-200/50 flex justify-between items-center">
        <div>
            <h2 className="text-2xl font-bold text-green-900 flex items-center gap-2">
            <SparklesIcon className="w-6 h-6 text-green-600"/>
            AI Assistant
            </h2>
            <p className="text-sm text-gray-600">Your personal garden designer.</p>
        </div>
        {isAuthReady && (
            <button
                onClick={onUploadApp}
                disabled={!isSignedIn || isUploadingApp}
                className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-semibold py-2 px-3 rounded-full shadow-md transition-all duration-300 flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed text-sm"
                title={isSignedIn ? "Upload app files to Google Drive" : "Sign in to upload app files"}
            >
                <DeployIcon className="w-5 h-5" />
                {isUploadingApp ? 'Uploading...' : 'Upload App'}
            </button>
        )}
      </div>
      <div className="flex-1 p-4 overflow-y-auto space-y-4">
        {messages.map((msg, index) => (
          <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-xs md:max-w-md lg:max-w-lg px-4 py-2 rounded-2xl ${msg.role === 'user' ? 'bg-green-600 text-white rounded-br-none' : 'bg-gray-200 text-gray-800 rounded-bl-none'}`}>
              <p className="whitespace-pre-wrap">{msg.text}</p>
            </div>
          </div>
        ))}
        {currentTranscription && (
           <div className="flex justify-end">
            <div className="max-w-xs md:max-w-md lg:max-w-lg px-4 py-2 rounded-2xl bg-green-200 text-green-800 rounded-br-none italic">
              <p>{currentTranscription}...</p>
            </div>
          </div>
        )}
         {isLoading && messages[messages.length - 1]?.role === 'user' && (
            <div className="flex justify-start">
                <div className="px-4 py-2 rounded-2xl bg-gray-200 text-gray-800 rounded-bl-none">
                    <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-gray-500 rounded-full animate-pulse"></div>
                        <div className="w-2 h-2 bg-gray-500 rounded-full animate-pulse delay-75"></div>
                        <div className="w-2 h-2 bg-gray-500 rounded-full animate-pulse delay-150"></div>
                    </div>
                </div>
            </div>
        )}
        <div ref={messagesEndRef} />
      </div>
      <div className="p-4 border-t border-green-200/50">
        <form onSubmit={handleSubmit} className="flex items-center gap-2">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={isRecording ? "Listening..." : "Describe your garden..."}
            className="flex-1 w-full pl-4 pr-10 py-2 border border-gray-300 rounded-full focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors"
            disabled={isRecording}
          />
          <button
            type="button"
            onClick={onToggleRecording}
            className={`p-3 rounded-full text-white transition-colors ${isRecording ? 'bg-red-500 hover:bg-red-600 animate-pulse' : 'bg-green-600 hover:bg-green-700'}`}
          >
            {isRecording ? <StopIcon className="w-6 h-6" /> : <MicIcon className="w-6 h-6" />}
          </button>
          <button
            type="submit"
            className="p-3 bg-green-600 text-white rounded-full hover:bg-green-700 transition-colors disabled:bg-gray-400"
            disabled={isRecording || !inputText.trim()}
          >
            <SendIcon className="w-6 h-6" />
          </button>
        </form>
      </div>
    </div>
  );
};

export default ChatPanel;