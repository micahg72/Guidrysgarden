
import { GoogleGenAI, Type, Modality, GenerateContentResponse, LiveServerMessage, Blob } from "@google/genai";
import { Plant } from '../types';
import { encode } from './utils';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  // A simple alert for demonstration purposes. In a real app, handle this more gracefully.
  alert("API_KEY environment variable not set. Please set it to use the application.");
  throw new Error("API_KEY not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export const getPlantSuggestions = async (prompt: string): Promise<Plant[]> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Based on the following query, provide a list of 5 suitable plants. Query: "${prompt}"`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING, description: "A unique identifier for the plant." },
              name: { type: Type.STRING, description: "The common name of the plant." },
              description: { type: Type.STRING, description: "A brief description of the plant." },
              careLevel: { type: Type.STRING, description: "Care level: Easy, Medium, or Hard." },
              season: { type: Type.STRING, description: "The primary season for the plant (e.g., Spring, Summer)." },
              type: { type: Type.STRING, description: "The type of plant (e.g., Flower, Shrub, Tree)." },
            },
            required: ["id", "name", "description", "careLevel", "season", "type"],
          },
        },
      },
    });

    const jsonText = response.text.trim();
    const plants = JSON.parse(jsonText);
    return plants;
  } catch (error) {
    console.error("Error fetching plant suggestions:", error);
    return [];
  }
};

export const visualizeGarden = async (prompt: string, baseImage: { data: string, mimeType: string } | null): Promise<string> => {
  try {
    if (baseImage) {
      // Image editing with gemini-2.5-flash-image
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [
            { inlineData: { data: baseImage.data, mimeType: baseImage.mimeType } },
            { text: prompt },
          ],
        },
        config: {
            responseModalities: [Modality.IMAGE],
        },
      });

      if (response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data) {
        return response.candidates[0].content.parts[0].inlineData.data;
      }
      throw new Error("No image data in response for editing.");

    } else {
      // Image generation with imagen-4.0
      const response = await ai.models.generateImages({
        model: 'imagen-4.0-generate-001',
        prompt: `A beautiful and realistic garden design featuring: ${prompt}`,
        config: {
          numberOfImages: 1,
          aspectRatio: '16:9',
          outputMimeType: 'image/jpeg',
        },
      });
      if (response.generatedImages?.[0]?.image?.imageBytes) {
        return response.generatedImages[0].image.imageBytes;
      }
      throw new Error("No image data in response for generation.");
    }
  } catch (error) {
    console.error("Error visualizing garden:", error);
    throw error;
  }
};

export const getSimpleChatResponse = async (prompt: string): Promise<string> => {
    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });
        return response.text;
    } catch (error) {
        console.error("Error getting chat response:", error);
        return "Sorry, I encountered an error. Please try again."
    }
};

export const startVoiceConversation = (callbacks: {
    onMessage: (message: LiveServerMessage) => void,
    onOpen: () => void,
    onError: (e: ErrorEvent) => void,
    onClose: (e: CloseEvent) => void,
}) => {
    return ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        callbacks: {
            onopen: callbacks.onOpen,
            onmessage: callbacks.onMessage,
            onerror: callbacks.onError,
            onclose: callbacks.onClose,
        },
        config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
                voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
            },
            inputAudioTranscription: {},
            outputAudioTranscription: {},
            systemInstruction: 'You are a friendly and helpful garden design assistant. Keep your responses concise and conversational.'
        }
    });
};

export const createAudioBlob = (data: Float32Array): Blob => {
    const l = data.length;
    const int16 = new Int16Array(l);
    for (let i = 0; i < l; i++) {
        int16[i] = data[i] * 32768;
    }
    return {
        data: encode(new Uint8Array(int16.buffer)),
        mimeType: 'audio/pcm;rate=16000',
    };
};
